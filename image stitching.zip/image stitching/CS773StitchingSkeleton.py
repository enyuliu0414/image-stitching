from itertools import count
from matplotlib import pyplot
from matplotlib.patches import Circle, ConnectionPatch
from timeit import default_timer as timer
from numpy.core.fromnumeric import trace
import imageIO.readwrite as IORW
import imageProcessing.pixelops as IPPixelOps
import imageProcessing.utilities as IPUtils
import imageProcessing.smoothing as IPSmooth
import numpy as np
import math
import random


# this is a helper function that puts together an RGB image for display in matplotlib, given
# three color channels for r, g, and b, respectively
def prepareRGBImageFromIndividualArrays(r_pixel_array,g_pixel_array,b_pixel_array,image_width,image_height):
    rgbImage = []
    for y in range(image_height):
        row = []
        for x in range(image_width):
            triple = []
            triple.append(r_pixel_array[y][x])
            triple.append(g_pixel_array[y][x])
            triple.append(b_pixel_array[y][x])
            row.append(triple)
        rgbImage.append(row)
    return rgbImage


# takes two images (of the same pixel size!) as input and returns a combined image of double the image width
def prepareMatchingImage(left_pixel_array, right_pixel_array, image_width, image_height):

    matchingImage = IPUtils.createInitializedGreyscalePixelArray(image_width * 2, image_height)
    for y in range(image_height):
        for x in range(image_width):
            matchingImage[y][x] = left_pixel_array[y][x]
            matchingImage[y][image_width + x] = right_pixel_array[y][x]

    return matchingImage
    
def cornerDetection(img,image_width,image_height,alpha):
    radius = 3
    sigma = 0.25*(radius*2)
    img = np.array(img)
    Ix_img=np.zeros([image_height,image_width])
    Iy_img=np.zeros([image_height,image_width])
    sobel_x=np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
    sobel_y=np.array([[-1,-2,-1],[0,0,0],[1,2,1]])
    for i in range(image_height-2):
        for j in range(image_width-2):
            Ix_img[i+1,j+1]=abs(np.sum(img[i:i+3,j:j+3]*sobel_x))
            Iy_img[i+1,j+1]=abs(np.sum(img[i:i+3,j:j+3]*sobel_y))
            
    Ix_2 = Ix_img * Ix_img
    Iy_2 = Iy_img * Iy_img
    I_xy = Ix_img * Iy_img

    Ix_2 = gaussianBlur(Ix_2,radius,sigma,image_width,image_height)
    Iy_2 = gaussianBlur(Iy_2,radius,sigma,image_width,image_height)
    I_xy = gaussianBlur(I_xy,radius,sigma,image_width,image_height)

    R_matrix = CornerDetection_RMatrix(Ix_2,Iy_2,I_xy,image_width,image_height,alpha)
    return R_matrix

def CornerDetection_RMatrix(Ix_2,Iy_2,I_xy,image_width,image_height,alpha):
    R = np.zeros((image_height,image_width),np.float32)
    for row in range(image_height):
        for column in range(image_width):
            M = np.array([[Ix_2[row][column],I_xy[row][column]],[I_xy[row][column],Iy_2[row][column]]])
            R[row][column] = np.linalg.det(M) - (alpha*np.square(np.trace(M)))
    return R
def Addcorner(R_matrix,image_width,image_height):
    corner_tuple = ()
    tuple_list = []
    for row in range(image_height):
        for column in range(image_width):
            if row >= 1 and row < image_height -1:
                if column >= 1 and column < image_width - 1:
                    if R_matrix[row][column] > R_matrix[row-1][column-1]:
                        if  R_matrix[row][column] > R_matrix[row - 1][column]:
                            if  R_matrix[row][column] > R_matrix[row-1][column+1]:
                                if  R_matrix[row][column] > R_matrix[row][column-1]:
                                    if  R_matrix[row][column] > R_matrix[row][column+1]:
                                        if  R_matrix[row][column] > R_matrix[row+1][column-1]:
                                            if  R_matrix[row][column] > R_matrix[row+1][column]:
                                                if  R_matrix[row][column] > R_matrix[row+1][column+1]:
                                                    corner_tuple = (column,row,R_matrix[row][column])
                                                    tuple_list.append(corner_tuple)
    return tuple_list
def sorting1000(corner_list):
    sorted_1000_list = []
    sorted_list = sorted(corner_list, key=lambda tup: tup[2],reverse=True)
    for i in range(1000):
        sorted_1000_list.append(sorted_list[i])

    return sorted_1000_list
def calculateWeights(sigma,x,y):
    weight = (1/(2*math.pi*sigma*sigma))*math.pow(math.e,((-(x*x+y*y))/((2*sigma)*(2*sigma))))
    return weight

def gaussianBlur(image_arry,radius,sigma,image_width,image_height):
    image_arry = np.array(image_arry)
    matrix_l = radius*2 + 1
    kernel_offset = matrix_l  // 2
    weight_matrix = np.zeros([matrix_l,matrix_l])
    for i in range(matrix_l):
        for j in range(matrix_l):
            weight_matrix[i][j] = calculateWeights(sigma,j-radius,i-radius)
    sum_weight = np.sum(weight_matrix)
    new_weight_matrix = weight_matrix/sum_weight
    after_gaussian_image = np.zeros([image_height,image_width])
    # for x in range(image_height-matrix_l+1):
    #     for y in range(image_width-matrix_l+1): 
    #         after_gaussian_image[x+kernel_offset,y+kernel_offset]= np.sum(image_arry[x:x+matrix_l,y:y+matrix_l]*new_weight_matrix)
    for x in range(image_height):
        for y in range(image_width): 
            if x >= kernel_offset and x < image_height - kernel_offset:
                if y >= kernel_offset and y < image_width - kernel_offset:
                   after_gaussian_image[x,y]= np.sum(image_arry[x-kernel_offset:x+kernel_offset+1,y-kernel_offset:y+kernel_offset+1]*new_weight_matrix)

    return after_gaussian_image
def NCC(image_left,image_right,list_left,list_right,image_height,image_width):
    match_list = []
    image_left = np.array(image_left)
    for i in range(len(list_left)):
        if list_left[i][0] - 7 >= 0 and list_left[i][1] - 7 >= 0:
            if  list_left[i][1] + 8 <= image_height and list_left[i][0] + 8 <= image_width:
                left_avg =  np.mean(image_left[list_left[i][1]-7:list_left[i][1]+8, list_left[i][0]-7:list_left[i][0]+8])
                left_std = image_left[list_left[i][1]-7:list_left[i][1]+8, list_left[i][0]-7:list_left[i][0]+8] - left_avg
                left_std = left_std*left_std
                left_std = np.sqrt(np.sum(left_std))       
                scorefirst , scoresecond = calculateCorrelationScore(image_left,list_left[i],left_avg,left_std,image_right,list_right,image_height,image_width)
                score_fiste_second = scorefirst + scoresecond
                match_list.append(score_fiste_second)


    return match_list
def calculateCorrelationScore(image_left,list_left,left_avg,left_std,image_right,list_right,image_height,image_width):
    image_right = np.array(image_right)
    rank_list = []
    for j in range(len(list_right)):
      if list_right[j][0]-7 >= 0 and list_right[j][1] - 7 >= 0:  
          if list_right[j][0] + 8 <= image_width and list_right[j][1] + 8 <= image_height: 
            right_avg = np.mean(image_right[list_right[j][1]-7:list_right[j][1]+8, list_right[j][0]-7:list_right[j][0]+8])
            right_std = image_right[list_right[j][1]-7:list_right[j][1]+8, list_right[j][0]-7:list_right[j][0]+8] - right_avg
            right_std = right_std * right_std
            right_std = np.sqrt(np.sum(right_std))
            image_left_diff_matrix = image_left[list_left[1]-7:list_left[1]+8,list_left[0]-7:list_left[0]+8] - left_avg
            image_right_diff_matrix = image_right[list_right[j][1]-7:list_right[j][1]+8,list_right[j][0]-7:list_right[j][0]+8] - right_avg
            scores = np.sum(image_right_diff_matrix * image_left_diff_matrix) / (left_std * right_std)
            score_tuple = ( list_left[0],list_left[1],list_right[j][0],list_right[j][1],scores)
            rank_list.append(score_tuple)
            sorted_score_list = sorted(rank_list, key=lambda tup: tup[4],reverse=True)
    return sorted_score_list[0],sorted_score_list[1]

def findGoodMatch(match_point_list,threshold):
    good_point_match_list = []
    for i in range(len(match_point_list)):
        score1 = match_point_list[i][4]
        score2 = match_point_list[i][9]
        if score2/score1 < threshold:
            good_point_match_list.append(match_point_list[i])
    return good_point_match_list
def pointsAreCollinear(p1, p2, p3):
    areaOfTriangle= 0.5 * (p1[0] * (p2[1] -p3[1]) + p2[0] * (p3[1] -p1[1]) + p3[0] * (p1[1] -p2[1]))
    return areaOfTriangle< 1e-5
def Homography(best_mact_list):
    M = []
    for i in range(len(best_mact_list)):
        point1 = [-best_mact_list[i][0],-best_mact_list[i][1],-1,0,0,0,best_mact_list[i][0]*best_mact_list[i][2],best_mact_list[i][1]*best_mact_list[i][2],best_mact_list[i][2]]
        M.append(point1)
        point2 = [0,0,0,-best_mact_list[i][0],-best_mact_list[i][1],-1,best_mact_list[i][0]*best_mact_list[i][3],best_mact_list[i][1]*best_mact_list[i][3],best_mact_list[i][3]]
        M.append(point2)
    M = np.array(M)
    U,S,V = np.linalg.svd(M)
    VT = V[8]/V[8][8]
    homography_matrix = np.zeros((3,3))
    index = 0
    for i in range(3):
        for j in range(3):
            homography_matrix[i][j] = VT[index]
            index += 1
    return homography_matrix
def CheckPoints(sample_points):
    point1 = (sample_points[0][0],sample_points[0][1])
    point2 = (sample_points[1][0],sample_points[1][1])
    point3 = (sample_points[2][0],sample_points[2][1])
    point4 = (sample_points[3][0],sample_points[3][1])
    if point1 != point2 and point1 != point3 and point1 != point4 and point2 != point3 and point2 != point4 and point3 != point4:
        return True
    else:
        return False
    

def computeRansacHomography(good_point_match_list, numberOfTries , Threshold ):
    best_count_inliers  = 0
    # best_homography_matrix = np.zeros((3,3))
    best_match = []
    for i in range(numberOfTries):
       inlier_match_list = []
       count_inliers = 0
       M = []
       sample_points = random.sample(good_point_match_list,4)
    #    if sample_points[0] != sample_points[1] and sample_points[0] != sample_points[2] and sample_points[0] != sample_points[3] and sample_points[1] != sample_points[2] and sample_points[1] != sample_points[3] and sample_points[2] != sample_points[3]:
       if CheckPoints(sample_points) and pointsAreCollinear(sample_points[0],sample_points[1],sample_points[2]) and pointsAreCollinear(sample_points[0],sample_points[1],sample_points[3]) and pointsAreCollinear(sample_points[1],sample_points[2],sample_points[3]) and pointsAreCollinear(sample_points[0],sample_points[2],sample_points[3]):
        #    for i in range(4):
        #       point1 = [-sample_points[i][0],-sample_points[i][1],-1,0,0,0,sample_points[i][0]*sample_points[i][2],sample_points[i][1]*sample_points[i][2],sample_points[i][2]]
        #       M.append(point1)
        #       point2 = [0,0,0,-sample_points[i][0],-sample_points[i][1],-1,sample_points[i][0]*sample_points[i][3],sample_points[i][1]*sample_points[i][3],sample_points[i][3]]
        #       M.append(point2)
        #    M = np.array(M)
        #    U,S,V = np.linalg.svd(M)
        #    VT = V[8]/V[8][8]
        #    homography_matrix = np.zeros((3,3))
        #    index = 0
        #    for i in range(3):
        #       for j in range(3):
        #          homography_matrix[i][j] = VT[index]
        #          index += 1
           homography_matrix = Homography(sample_points)
           for i in range(len(good_point_match_list)):
               x = good_point_match_list[i][0]
               y = good_point_match_list[i][1]
               point_vector = np.array([x,y,1])
               x1 = good_point_match_list[i][2]
               y1 = good_point_match_list[i][3]
               predice_matrix = homography_matrix.dot(point_vector)
               predice_matrix = np.array(predice_matrix)
               predice_matrix = predice_matrix/predice_matrix[2]
               if np.sqrt(pow((predice_matrix[0] - x1),2) + pow((predice_matrix[1]-y1),2)) < Threshold:
                  count_inliers += 1
                  inlier_match_list.append(good_point_match_list[i])

           if best_count_inliers < count_inliers:
              best_count_inliers = count_inliers
            #   best_homography_matrix = homography_matrix
              best_match = inlier_match_list
    if best_count_inliers < len(good_point_match_list)/2:
       computeRansacHomography(good_point_match_list, numberOfTries , Threshold )
    else:
       return best_count_inliers,best_match
    
def warpingPerspectiveForward(left_img, right_img, image_width, image_height, homography, blend_factor = 0.5):

    # createInitializedGreyscalePixelArray
    warped = [[0 for x in range(2 * image_width)] for y in range(image_height)]

    # with u and v we go over the pixel grid of the output warped image, which is twice the size of the left image
    for v in range(image_height):
        for u in range(2 * image_width):
            # transform u,v to point p in homogeneous coordinates (stored as numpy array)
            p_hom = np.asarray([u, v, 1])
            p_transformed_hom = np.dot(homography, p_hom)
            # transform back from homogoneous coordinates to a point "x, y" in R^2
            # x, y is the point in the left image, falling between 4 pixels
            x = p_transformed_hom[0] / p_transformed_hom[2]
            y = p_transformed_hom[1] / p_transformed_hom[2]

            # pixel top left is the one we get after we convert floats to ints
            x1 = math.floor(x)
            y1 = math.floor(y)

            value_from_right_img = 0.0
            value_from_right_img_computed = False
            # need to check if that one is outside the bounds of the right image
            if x1 >= 0 and x1 < image_width-1 and y1 >= 0 and y1 < image_height-1:
                a = x-x1
                b = y-y1

                value_from_right_img_computed = True
                value_from_right_img += (1.0 - a) * (1.0 - b) * right_img[y1][x1]
                value_from_right_img += a * b * right_img[y1+1][x1+1]
                value_from_right_img += (1.0 - a) * b * right_img[y1+1][x1]
                value_from_right_img += a * (1.0 - b) * right_img[y1][x1+1]

            # if we are over a pixel of the left image, we need to blend
            if u <= image_width - 1:
                value_from_left_img = left_img[v][u]
                if value_from_right_img_computed:
                    warped[v][u] = blend_factor * value_from_left_img + (1.0 - blend_factor) * value_from_right_img
                else:
                    warped[v][u] = value_from_left_img
            else:
                warped[v][u] = value_from_right_img

    return warped


# This is our code skeleton that performs the stitching
def main():
    alpha = 0.04
    filename_left_image = "./images/panoramaStitching/tongariro_left_01.png"
    filename_right_image = "./images/panoramaStitching/tongariro_right_01.png"

    (image_width, image_height, px_array_left_original)  = IORW.readRGBImageAndConvertToGreyscalePixelArray(filename_left_image)
    (image_width, image_height, px_array_right_original) = IORW.readRGBImageAndConvertToGreyscalePixelArray(filename_right_image)

    start = timer()
    px_array_left = IPSmooth.computeGaussianAveraging3x3(px_array_left_original, image_width, image_height)
    px_array_right = IPSmooth.computeGaussianAveraging3x3(px_array_right_original, image_width, image_height)
    end = timer()
    print("elapsed time image smoothing: ", end - start)

    # make sure greyscale image is stretched to full 8 bit intensity range of 0 to 255
    px_array_left = IPPixelOps.scaleTo0And255AndQuantize(px_array_left, image_width, image_height)
    px_array_right = IPPixelOps.scaleTo0And255AndQuantize(px_array_right, image_width, image_height)

    R_matrix = cornerDetection(px_array_left,image_width,image_height,alpha)
    R_matrix_right = cornerDetection(px_array_right,image_width,image_height,alpha)


    # only put a corner into the tuple which is larger than all its 8 immediate neighbours
    corner_list = Addcorner(R_matrix,image_width,image_height)
    corner_list_right = Addcorner(R_matrix_right,image_width,image_height)
    #sorting top 1000 corners 
    sorted_1000_list = sorting1000(corner_list)
    sorted_1000_list_right = sorting1000(corner_list_right)

    match_point_list = NCC(px_array_left,px_array_right,sorted_1000_list,sorted_1000_list_right,image_height,image_width)
    threshold = 0.9
    good_point_match_list = findGoodMatch(match_point_list,threshold)
    numberOfTries = 1000
    Threshold = 2
    best_count_inliers,best_match = computeRansacHomography(good_point_match_list, numberOfTries , Threshold)
    homography_matrix = Homography(best_match)
    print(homography_matrix)
    print(best_count_inliers)




    # some visualizations

    fig1, axs1 = pyplot.subplots(1, 2)

    axs1[0].set_title('Harris response left overlaid on orig image')
    axs1[1].set_title('Harris response right overlaid on orig image')
    axs1[0].imshow(px_array_left, cmap='gray')
    axs1[1].imshow(px_array_right, cmap='gray')

    # plot a red point in the center of each image
    for i in range(1000):
        circle = Circle((sorted_1000_list[i][0],sorted_1000_list[i][1]), 0.3, color='r')
        axs1[0].add_patch(circle)
    for j in range(len(sorted_1000_list_right)):
        circle_right = Circle((sorted_1000_list_right[j][0],sorted_1000_list_right[j][1]), 0.3, color='r')
        axs1[1].add_patch(circle_right)

    pyplot.show()

    # a combined image including a red matching line as a connection patch artist (from matplotlib\)

    matchingImage = prepareMatchingImage(px_array_left, px_array_right, image_width, image_height)

    pyplot.imshow(matchingImage, cmap='gray')
    ax = pyplot.gca()
    ax.set_title("Matching image")


    for i in range(len(best_match)):
        pointA = (best_match[i][0],best_match[i][1])
        pointB = (best_match[i][2] + image_width, best_match[i][3])
        connection = ConnectionPatch(pointA, pointB, "data", edgecolor='r', linewidth=0.3)
        ax.add_artist(connection)

    pyplot.show()
    

    image_width1, image_height1,leftimageR, leftimageG, leftimageB = IORW.readRGBImageToSeparatePixelArrays(filename_left_image)
    image_width1, image_height1,rightimageR, rightimageG, rightimageB = IORW.readRGBImageToSeparatePixelArrays(filename_right_image)

    ImageR =  warpingPerspectiveForward(leftimageR, rightimageR, image_width, image_height, homography_matrix, blend_factor = 0.5)
    ImageG =  warpingPerspectiveForward(leftimageG, rightimageG, image_width, image_height, homography_matrix, blend_factor = 0.5)
    ImageB =  warpingPerspectiveForward(leftimageB, rightimageB, image_width, image_height, homography_matrix, blend_factor = 0.5)
    w = len(ImageR[0])
    h = len(ImageR)

    ImageRGB = prepareRGBImageFromIndividualArrays(ImageR,ImageG,ImageB,w,h)
    ImageRGB = np.array(ImageRGB)/255

    # ImageS =  warpingPerspectiveForward(px_array_left_original, px_array_right_original, image_width, image_height, homography_matrix, blend_factor = 0.5)
    pyplot.imshow(ImageRGB)
    pyplot.show()



if __name__ == "__main__":
    main()

